import React, { useState } from 'react';
import Navbar from './components/Navbar';
import ParticleBackground from './components/ParticleBackground';
import TaskPage from './pages/TaskPage';
import HistoryPage from './pages/HistoryPage';
import SchedulesPage from './pages/SchedulesPage';
import SettingsPage from './pages/SettingsPage';
import DashboardPage from './pages/DashboardPage';
import WorkflowsPage from './pages/WorkflowsPage';
import NewsPage from './pages/NewsPage';
import ReportsPage from './pages/ReportsPage';
import MonitoringPage from './pages/MonitoringPage';
import { ShieldCheck, Heart } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('tasks');

  return (
    <div className="min-h-screen flex flex-col bg-[#080c14] text-slate-100 relative selection:bg-cyan-500 selection:text-black">
      {/* Dynamic Glow Particle Background */}
      <ParticleBackground />

      {/* Sticky Navigation Bar */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {activeTab === 'tasks' && <TaskPage onTaskCompleted={() => {}} />}
        {activeTab === 'workflows' && <WorkflowsPage />}
        {activeTab === 'reports' && <ReportsPage />}
        {activeTab === 'monitoring' && <MonitoringPage />}
        {activeTab === 'news' && <NewsPage />}
        {activeTab === 'history' && <HistoryPage />}
        {activeTab === 'schedules' && <SchedulesPage />}
        {activeTab === 'dashboard' && <DashboardPage />}
        {activeTab === 'settings' && <SettingsPage />}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-6 text-center text-xs text-slate-400 glass-panel">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>100% Private Local Inference • No Paid APIs • Sandboxed to <code className="text-cyan-300 font-mono">workspace/</code></span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-400">
            <span>Built for students, job seekers, & businesses in India</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
