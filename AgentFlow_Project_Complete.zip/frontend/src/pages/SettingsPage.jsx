import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Settings,
  Save,
  User,
  Mail,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  ShieldCheck,
  Cpu,
  Key,
  BookOpen,
  Eye,
  Info,
  Plug,
  Layers,
  Send,
  Search,
  Newspaper,
  HardDrive,
  ExternalLink,
  ArrowRight,
  Zap,
  Check,
  Copy
} from 'lucide-react';

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('integrations'); // 'integrations' | 'templates' | 'memory'

  // Preferences & Memory State
  const [settings, setSettings] = useState({
    user_name: '',
    default_email: '',
    writing_style: 'Professional, concise, and courteous Indian business English',
    user_role: 'Software Engineer & AI Enthusiast',
    location: 'India (IST)',
    currency_preference: 'INR (₹)',
    custom_instructions: 'Always summarize key points into bullet points first. Always use Indian Standard Time (IST) and currency in INR (₹).'
  });

  // Integrations State
  const [integrations, setIntegrations] = useState([]);
  const [testingService, setTestingService] = useState(null);
  const [integrationStatuses, setIntegrationStatuses] = useState({});

  // Workflow Templates State
  const [templates, setTemplates] = useState([]);
  const [cloningId, setCloningId] = useState(null);
  const [clonedSuccess, setClonedSuccess] = useState(null);

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [toast, setToast] = useState(null);
  const [showPromptPreview, setShowPromptPreview] = useState(false);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    setIsLoading(true);
    try {
      // 1. Fetch user settings
      const sResp = await fetch('/api/settings');
      if (sResp.ok) {
        const sData = await sResp.json();
        setSettings(prev => ({ ...prev, ...(sData.settings || {}) }));
      }

      // 2. Fetch integrations status
      const iResp = await fetch('/api/integrations/status');
      if (iResp.ok) {
        const iData = await iResp.json();
        setIntegrations(iData.services || []);
        const statusMap = {};
        (iData.services || []).forEach(s => {
          statusMap[s.service] = s;
        });
        setIntegrationStatuses(statusMap);
      }

      // 3. Fetch workflow templates
      const tResp = await fetch('/api/workflows/templates');
      if (tResp.ok) {
        const tData = await tResp.json();
        setTemplates(tData.templates || []);
      }
    } catch (e) {
      console.error('Failed to load initial settings data', e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTestIntegration = async (serviceName) => {
    setTestingService(serviceName);
    try {
      const resp = await fetch(`/api/integrations/test/${serviceName}`, { method: 'POST' });
      const data = await resp.json();
      setIntegrationStatuses(prev => ({ ...prev, [serviceName]: data }));
    } catch (e) {
      console.error(`Test failed for ${serviceName}:`, e);
    } finally {
      setTestingService(null);
    }
  };

  const handleUseTemplate = async (templateId) => {
    setCloningId(templateId);
    setClonedSuccess(null);
    try {
      const resp = await fetch(`/api/workflows/from-template/${templateId}`, { method: 'POST' });
      const data = await resp.json();
      if (resp.ok) {
        setClonedSuccess({
          id: data.workflow_id,
          title: data.plan?.title || 'Workflow'
        });
      }
    } catch (e) {
      console.error('Failed to instantiate template:', e);
    } finally {
      setCloningId(null);
    }
  };

  const handleSavePreferences = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    setToast(null);

    try {
      const resp = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings })
      });

      if (resp.ok) {
        setToast({ type: 'success', text: 'Memory & personalization preferences saved successfully!' });
      } else {
        setToast({ type: 'error', text: 'Failed to update preferences.' });
      }
    } catch (e) {
      setToast({ type: 'error', text: 'Error communicating with backend.' });
    } finally {
      setIsSaving(false);
      setTimeout(() => setToast(null), 4000);
    }
  };

  const getServiceIcon = (service) => {
    switch (service) {
      case 'ollama': return Cpu;
      case 'telegram': return Send;
      case 'email': return Mail;
      case 'search': return Search;
      case 'news': return Newspaper;
      case 'workspace': return HardDrive;
      default: return Plug;
    }
  };

  const getStatusBadge = (status) => {
    if (status === 'connected') {
      return (
        <span className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span> Connected
        </span>
      );
    }
    if (status === 'not_configured') {
      return (
        <span className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-slate-800 text-slate-400 border border-slate-700">
          Not Configured
        </span>
      );
    }
    if (status === 'offline') {
      return (
        <span className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-rose-500/10 text-rose-400 border border-rose-500/20">
          Offline
        </span>
      );
    }
    return (
      <span className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20">
        Degraded
      </span>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold font-display text-white">Integrations & Settings Hub</h1>
              <p className="text-sm text-slate-400">
                Verify service connections, browse ready-to-run workflow templates, and personalize your agent.
              </p>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900/60 border border-white/10 glass-panel">
          <button
            onClick={() => setActiveTab('integrations')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'integrations'
                ? 'bg-cyan-500 text-black shadow-glow-cyan'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Plug className="w-3.5 h-3.5" />
            <span>Integrations</span>
          </button>
          <button
            onClick={() => setActiveTab('templates')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'templates'
                ? 'bg-cyan-500 text-black shadow-glow-cyan'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Templates ({templates.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('memory')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'memory'
                ? 'bg-cyan-500 text-black shadow-glow-cyan'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Personalization</span>
          </button>
        </div>
      </div>

      {/* Toast Notification */}
      {toast && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-xl text-xs sm:text-sm flex items-center gap-2 border ${
            toast.type === 'success'
              ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'
              : 'bg-rose-500/10 text-rose-300 border-rose-500/20'
          }`}
        >
          {toast.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          <span>{toast.text}</span>
        </motion.div>
      )}

      {/* Cloned Template Alert */}
      {clonedSuccess && (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-glow-cyan"
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0" />
            <span>Workflow <strong>"{clonedSuccess.title}"</strong> created successfully ({clonedSuccess.id})!</span>
          </div>
          <span className="text-[11px] text-cyan-300 underline font-mono">
            Switch to the <strong>Workflows</strong> tab to view and dry-run its step graph.
          </span>
        </motion.div>
      )}

      {/* TAB 1: INTEGRATIONS HUB */}
      {activeTab === 'integrations' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Plug className="w-3.5 h-3.5 text-cyan-400" /> Active Service Connections
            </span>
            <span className="text-xs text-slate-500">100% Free • Secrets Stored Locally</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {integrations.map((svc) => {
              const currentStatus = integrationStatuses[svc.service] || svc;
              const Icon = getServiceIcon(svc.service);
              const isTesting = testingService === svc.service;

              return (
                <motion.div
                  key={svc.service}
                  whileHover={{ y: -2 }}
                  className="p-5 rounded-2xl border border-white/10 bg-slate-900/40 glass-panel flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-xl bg-white/5 border border-white/10 text-cyan-400">
                          <Icon className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-sm text-white">{svc.display_name}</h3>
                          <div className="text-[11px] text-slate-400 font-mono">
                            {currentStatus.latency_ms ? `${currentStatus.latency_ms} ms` : 'Local Probe'}
                          </div>
                        </div>
                      </div>
                      {getStatusBadge(currentStatus.status)}
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed">
                      {currentStatus.message}
                    </p>

                    {currentStatus.guidance && (
                      <div className="p-2.5 rounded-lg bg-black/40 border border-white/5 text-[11px] text-slate-400 font-mono leading-relaxed">
                        {currentStatus.guidance}
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                      {svc.service.toUpperCase()}
                    </span>
                    <button
                      onClick={() => handleTestIntegration(svc.service)}
                      disabled={isTesting}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-200 font-medium transition-colors"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin text-cyan-400' : 'text-slate-400'}`} />
                      <span>{isTesting ? 'Testing...' : 'Test Connection'}</span>
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: WORKFLOW TEMPLATES GALLERY */}
      {activeTab === 'templates' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Curated Indian Workflow Templates
            </span>
            <span className="text-xs text-slate-500">One-click visual step graph instantiation</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {templates.map((tpl) => {
              const isCloning = cloningId === tpl.id;
              return (
                <motion.div
                  key={tpl.id}
                  whileHover={{ y: -2 }}
                  className="p-5 rounded-2xl border border-white/10 bg-slate-900/40 glass-panel flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                        {tpl.category}
                      </span>
                      <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-violet-500/10 text-violet-300 border border-violet-500/20">
                        {tpl.badge}
                      </span>
                    </div>

                    <div>
                      <h3 className="font-bold text-sm text-white mb-1">{tpl.title}</h3>
                      <p className="text-xs text-slate-400 leading-relaxed mb-3">{tpl.description}</p>
                    </div>

                    <div className="space-y-1.5">
                      <div className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">
                        Registered Tools ({tpl.tools_used?.length || 0}):
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {tpl.tools_used?.map((tool) => (
                          <span
                            key={tool}
                            className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono border border-white/5"
                          >
                            {tool}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                    <span className="text-[11px] text-slate-500 font-mono">
                      Target: {tpl.target_audience.split('&')[0]}
                    </span>
                    <button
                      onClick={() => handleUseTemplate(tpl.id)}
                      disabled={isCloning}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-semibold shadow-glow-cyan transition-all"
                    >
                      {isCloning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
                      <span>{isCloning ? 'Instantiating...' : 'Use Template'}</span>
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: PERSONALIZATION & MEMORY */}
      {activeTab === 'memory' && (
        <form onSubmit={handleSavePreferences} className="space-y-6">
          <div className="p-6 rounded-2xl border border-white/10 bg-slate-900/40 glass-panel space-y-5">
            <div>
              <h2 className="text-base font-bold text-white mb-1 flex items-center gap-2">
                <User className="w-4 h-4 text-cyan-400" /> User Profile & Memory
              </h2>
              <p className="text-xs text-slate-400">
                These preferences are automatically injected into the agent's system prompt on every execution.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Your Name</label>
                <input
                  type="text"
                  placeholder="e.g. Insha Fatima"
                  value={settings.user_name}
                  onChange={(e) => setSettings({ ...settings, user_name: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-white/10 text-slate-200 text-xs focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Notification Email</label>
                <input
                  type="email"
                  placeholder="e.g. your_email@gmail.com"
                  value={settings.default_email}
                  onChange={(e) => setSettings({ ...settings, default_email: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-white/10 text-slate-200 text-xs focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Location / Timezone</label>
                <input
                  type="text"
                  value={settings.location}
                  onChange={(e) => setSettings({ ...settings, location: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-white/10 text-slate-200 text-xs focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Currency Preference</label>
                <input
                  type="text"
                  value={settings.currency_preference}
                  onChange={(e) => setSettings({ ...settings, currency_preference: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-white/10 text-slate-200 text-xs focus:border-cyan-500 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Role / Persona</label>
              <input
                type="text"
                placeholder="e.g. SMB Founder, Student, Job Seeker"
                value={settings.user_role}
                onChange={(e) => setSettings({ ...settings, user_role: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-white/10 text-slate-200 text-xs focus:border-cyan-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Custom Agent Instructions</label>
              <textarea
                rows={3}
                placeholder="Specific instructions to adhere to across all tasks..."
                value={settings.custom_instructions}
                onChange={(e) => setSettings({ ...settings, custom_instructions: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-white/10 text-slate-200 text-xs focus:border-cyan-500 outline-none resize-none"
              />
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={isSaving}
                className="flex items-center gap-2 px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-semibold shadow-glow-cyan transition-all"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{isSaving ? 'Saving...' : 'Save Preferences'}</span>
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}
