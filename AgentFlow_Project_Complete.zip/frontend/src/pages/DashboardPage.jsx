import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  Wrench, 
  Zap, 
  IndianRupee, 
  ShieldCheck, 
  RefreshCw,
  Sparkles,
  ArrowUpRight,
  PieChart as PieIcon,
  Activity
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid
} from 'recharts';

export default function DashboardPage() {
  const [stats, setStats] = useState({
    total_tasks: 0,
    completed_tasks: 0,
    success_rate: 100,
    tool_usage: [],
    estimated_minutes_saved: 0,
    hours_saved: 0,
    financial_savings_inr: 0,
    tasks_timeline: []
  });

  const [isLoading, setIsLoading] = useState(true);

  const fetchStats = async () => {
    setIsLoading(true);
    try {
      const resp = await fetch('/api/stats');
      if (resp.ok) {
        const data = await resp.json();
        setStats(data);
      }
    } catch (e) {
      console.error('Failed to load metrics', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  // Neon color palette for tools and charts
  const TOOL_COLORS = {
    web_search: '#06b6d4',      // Cyan
    save_file: '#10b981',       // Emerald
    read_file: '#8b5cf6',       // Violet
    list_files: '#f59e0b',      // Amber
    get_datetime: '#ec4899',    // Pink
    send_email: '#3b82f6',      // Blue
  };

  const DEFAULT_COLORS = ['#06b6d4', '#8b5cf6', '#10b981', '#f59e0b', '#ec4899', '#3b82f6'];

  // Tool usage data with formatted names and fallback colors
  const toolChartData = (stats.tool_usage || []).map((t, idx) => ({
    name: t.tool.replace(/_/g, ' '),
    rawTool: t.tool,
    count: t.count,
    fill: TOOL_COLORS[t.tool] || DEFAULT_COLORS[idx % DEFAULT_COLORS.length]
  }));

  // Fallback demo tool usage if fresh database has few records
  const displayToolData = toolChartData.length > 0 ? toolChartData : [
    { name: 'web search', rawTool: 'web_search', count: 12, fill: '#06b6d4' },
    { name: 'save file', rawTool: 'save_file', count: 8, fill: '#10b981' },
    { name: 'read file', rawTool: 'read_file', count: 6, fill: '#8b5cf6' },
    { name: 'get datetime', rawTool: 'get_datetime', count: 4, fill: '#ec4899' },
    { name: 'send email', rawTool: 'send_email', count: 3, fill: '#3b82f6' },
  ];

  // Timeline data formatted
  const timelineData = (stats.tasks_timeline || []).map(item => ({
    date: item.date,
    Completed: item.completed,
    Total: item.total
  }));

  const displayTimeline = timelineData.length > 0 ? timelineData : [
    { date: 'Mon', Completed: 3, Total: 3 },
    { date: 'Tue', Completed: 5, Total: 5 },
    { date: 'Wed', Completed: 4, Total: 5 },
    { date: 'Thu', Completed: 6, Total: 6 },
    { date: 'Fri', Completed: 7, Total: 7 },
    { date: 'Today', Completed: stats.completed_tasks || 8, Total: stats.total_tasks || 8 },
  ];

  // Custom Dark Tooltip
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-panel p-3 rounded-xl border border-white/10 shadow-2xl text-xs space-y-1 bg-slate-900/95">
          <p className="font-semibold text-slate-200">{label}</p>
          {payload.map((entry, index) => (
            <p key={`item-${index}`} style={{ color: entry.color || entry.fill }}>
              {entry.name}: <strong className="text-white">{entry.value}</strong>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8 animate-fade-in">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-medium mb-2">
            <Activity className="w-3.5 h-3.5" />
            <span>Real-Time Performance & ROI Analytics</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            Agent Analytics & Impact
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Track automated tasks, tool usage frequency, and estimated productivity gains.
          </p>
        </div>

        <button
          type="button"
          onClick={fetchStats}
          className="p-2 self-start sm:self-auto rounded-xl glass-card border border-white/10 text-slate-400 hover:text-white transition-colors"
          title="Refresh metrics"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Total Tasks Card */}
        <div className="glass-card rounded-2xl p-5 border border-white/10 hover:border-cyan-500/30 transition-all space-y-3 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total Tasks Run</span>
            <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-3xl font-extrabold font-display text-white">
              {stats.total_tasks}
            </div>
            <p className="text-[11px] text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              <span>{stats.completed_tasks} completed autonomously</span>
            </p>
          </div>
        </div>

        {/* Success Rate Card */}
        <div className="glass-card rounded-2xl p-5 border border-white/10 hover:border-emerald-500/30 transition-all space-y-3 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Success Rate</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-3xl font-extrabold font-display text-emerald-400">
              {stats.success_rate}%
            </div>
            <p className="text-[11px] text-slate-400">
              Based on executed ReAct loops
            </p>
          </div>
        </div>

        {/* Hours Saved Card */}
        <div className="glass-card rounded-2xl p-5 border border-white/10 hover:border-violet-500/30 transition-all space-y-3 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Time Saved</span>
            <div className="w-8 h-8 rounded-xl bg-violet-500/10 border border-violet-500/20 text-violet-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-3xl font-extrabold font-display text-violet-300">
              {stats.hours_saved} <span className="text-sm font-normal text-slate-400">hrs</span>
            </div>
            <p className="text-[11px] text-violet-400">
              ~{stats.estimated_minutes_saved} manual working minutes
            </p>
          </div>
        </div>

        {/* Financial Value (INR) Card */}
        <div className="glass-card rounded-2xl p-5 border border-white/10 hover:border-amber-500/30 transition-all space-y-3 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Est. Value Created</span>
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
              <IndianRupee className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-3xl font-extrabold font-display text-amber-300">
              ₹{stats.financial_savings_inr?.toLocaleString('en-IN') || 0}
            </div>
            <p className="text-[11px] text-amber-400/90">
              @ ₹500/hr digital assistant benchmark
            </p>
          </div>
        </div>

      </div>

      {/* Visual Analytics Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Tasks Timeline Area Chart */}
        <div className="lg:col-span-2 glass-panel rounded-2xl p-5 border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-semibold text-white">Execution Trend</h3>
            </div>
            <span className="text-[11px] text-slate-400">Tasks Executed vs Completed</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={displayTimeline} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorCompleted" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} allowDecimals={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="monotone" 
                  dataKey="Total" 
                  stroke="#06b6d4" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#colorTotal)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="Completed" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#colorCompleted)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Tool Distribution Pie / Bar Chart */}
        <div className="glass-panel rounded-2xl p-5 border border-white/10 space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Wrench className="w-4 h-4 text-violet-400" />
              <h3 className="text-sm font-semibold text-white">Tool Invocations</h3>
            </div>
            <span className="text-[11px] text-slate-400">Total Tool Actions</span>
          </div>

          <div className="h-48 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Tooltip content={<CustomTooltip />} />
                <Pie
                  data={displayToolData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="count"
                >
                  {displayToolData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} stroke="#0f172a" strokeWidth={2} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Tool Chips Legend */}
          <div className="flex flex-wrap gap-2 pt-2 border-t border-white/5">
            {displayToolData.map((t) => (
              <div 
                key={t.name}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/5 border border-white/5 text-[11px]"
              >
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: t.fill }}></span>
                <span className="text-slate-300 capitalize">{t.name}</span>
                <span className="text-slate-400 font-mono font-semibold">({t.count})</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Target User Impact & Value Delivered */}
      <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
        <h3 className="text-sm font-semibold text-white flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span>Why AgentFlow Wins: Free, Private & Tailored for India</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-cyan-500/5 border border-cyan-500/20 space-y-2">
            <div className="flex items-center gap-2 text-cyan-300 font-semibold">
              <ShieldCheck className="w-4 h-4" />
              <span>100% Free & Local Inference</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Powered by local Ollama on your own GPU/CPU. Zero API keys, zero subscription costs, saving thousands of rupees monthly compared to proprietary closed models.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-violet-500/5 border border-violet-500/20 space-y-2">
            <div className="flex items-center gap-2 text-violet-300 font-semibold">
              <Clock className="w-4 h-4" />
              <span>Permission Before Action</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Human-in-the-loop approvals safeguard your Gmail and local files. The agent pauses and displays full parameters before sending an email or overwriting files.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20 space-y-2">
            <div className="flex items-center gap-2 text-emerald-300 font-semibold">
              <Zap className="w-4 h-4" />
              <span>Multi-Lingual Voice & Workflows</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Understands English, Hindi (हिन्दी), and Urdu (اردو). Pre-configured templates for students, job seekers, and small business owners in India.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
}
