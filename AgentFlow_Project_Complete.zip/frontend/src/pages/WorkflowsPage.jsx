import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Play, 
  Square, 
  RotateCw, 
  Key, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle, 
  Terminal, 
  Layers, 
  History, 
  Trash2, 
  ArrowRight,
  Zap,
  Info,
  ExternalLink,
  MessageSquare,
  HelpCircle
} from 'lucide-react';
import WorkflowGraph from '../components/WorkflowGraph';
import VoiceInputButton from '../components/VoiceInputButton';
import QuestionsPanel from '../components/QuestionsPanel';

const WORKFLOW_TEMPLATES = [
  {
    title: 'Daily AI News Digest',
    category: 'News & Media',
    prompt: 'Check current IST time, fetch latest AI news in India, and save to workspace/ai_daily_news.txt',
    badge: '1-Click'
  },
  {
    title: 'Job Market & Skills Analysis',
    category: 'Job Seekers',
    prompt: 'Search top 5 in-demand skills for AI and software engineers in India in 2026, summarize them, and save to workspace/ai_engineer_skills.txt',
    badge: 'Popular'
  },
  {
    title: 'Freelance Contract Generator',
    category: 'Small Business',
    prompt: 'Mujhe freelance digital marketing contract ka professional template bana kar workspace/marketing_agreement.txt me save karo aur IST time audit karo',
    badge: 'Hindi / Hinglish'
  },
  {
    title: 'Daily Lucknow Weather Email',
    category: 'Personal Daily',
    prompt: 'Send me the weather report of Lucknow every day at 5 PM by email',
    badge: 'Stage 1 Tested'
  },
  {
    title: 'Automated Digest to Email',
    category: 'Automation',
    prompt: 'Check current time and email a daily summary report of today AI news to user@example.com',
    badge: 'Approval Required'
  }
];

export default function WorkflowsPage() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [dryRun, setDryRun] = useState(false);
  const [currentPlan, setCurrentPlan] = useState(null);
  const [activeStepId, setActiveStepId] = useState(null);
  const [selectedStep, setSelectedStep] = useState(null);
  const [logs, setLogs] = useState([]);
  const [workflowsHistory, setWorkflowsHistory] = useState([]);
  const [selectedHistoryWorkflow, setSelectedHistoryWorkflow] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [questionsSession, setQuestionsSession] = useState(null);
  const [isExtracting, setIsExtracting] = useState(false);
  const [isAnswering, setIsAnswering] = useState(false);
  const eventSourceRef = useRef(null);
  const logContainerRef = useRef(null);

  // Auto-scroll logs
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  // Load saved workflows on mount
  useEffect(() => {
    fetchWorkflows();
  }, []);

  const fetchWorkflows = async () => {
    try {
      const res = await fetch('/api/workflows');
      if (res.ok) {
        const data = await res.json();
        setWorkflowsHistory(data.workflows || []);
      }
    } catch (e) {
      console.warn('Failed to fetch workflows:', e);
    }
  };

  const handleGeneratePlan = async (promptOverride) => {
    const textToUse = (promptOverride || prompt).trim();
    if (!textToUse) return;

    setErrorMsg('');
    setIsGenerating(true);
    setCurrentPlan(null);
    setLogs([]);
    setActiveStepId(null);
    setSelectedStep(null);

    try {
      const res = await fetch('/api/workflows/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: textToUse })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.detail || 'Failed to generate workflow plan');
      }

      const plan = await res.json();
      setCurrentPlan(plan);
      setSelectedStep(plan.steps && plan.steps[0] ? plan.steps[0] : null);
      fetchWorkflows();
    } catch (err) {
      setErrorMsg(err.message || 'Error communicating with Workflow Architect');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExtractAndBuildWorkflow = async (promptOverride) => {
    const textToUse = (promptOverride || prompt).trim();
    if (!textToUse) return;

    setErrorMsg('');
    setIsExtracting(true);
    setQuestionsSession(null);

    try {
      const res = await fetch('/api/workflows/extract-requirements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: textToUse })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || 'Failed to inspect workflow requirements');
      }

      const session = await res.json();
      setQuestionsSession(session);

      // If all inputs were already provided in the prompt, generate plan immediately!
      if (session.is_complete || (session.questions && session.questions.length === 0)) {
        await handleGeneratePlan(textToUse);
      }
    } catch (err) {
      console.warn('Requirement extraction error:', err);
      // Fallback: direct plan generation
      await handleGeneratePlan(textToUse);
    } finally {
      setIsExtracting(false);
    }
  };

  const handleAnswerQuestion = async (field, answer) => {
    if (!questionsSession) return;
    setIsAnswering(true);
    setErrorMsg('');

    try {
      const res = await fetch('/api/workflows/answer-question', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session: questionsSession,
          field: field,
          answer: answer
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || 'Failed to submit answer');
      }

      const updated = await res.json();
      setQuestionsSession(updated);

      if (updated.is_complete) {
        // Synthesize enriched prompt with all verified inputs
        let enriched = updated.prompt;
        if (updated.known_inputs && Object.keys(updated.known_inputs).length > 0) {
          const paramsList = Object.entries(updated.known_inputs)
            .map(([k, v]) => `${k}: ${v}`)
            .join(', ');
          enriched = `${updated.prompt} (Inputs: ${paramsList})`;
        }
        await handleGeneratePlan(enriched);
      }
    } catch (err) {
      setErrorMsg(err.message || 'Error processing response');
    } finally {
      setIsAnswering(false);
    }
  };

  const handleRunWorkflow = () => {
    if (!currentPlan || !currentPlan.workflow_id) return;

    setIsRunning(true);
    setErrorMsg('');
    setLogs([]);

    const streamUrl = `/api/workflows/${currentPlan.workflow_id}/stream?dry_run=${dryRun ? 'true' : 'false'}`;
    const es = new EventSource(streamUrl);
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        const timestamp = new Date().toLocaleTimeString();

        if (data.type === 'workflow_start') {
          setLogs((prev) => [...prev, `[${timestamp}] 🚀 Workflow started: "${data.title}" (Dry-run: ${data.dry_run})`]);
        } else if (data.type === 'step_start') {
          setActiveStepId(data.step_id);
          setCurrentPlan((prev) => {
            if (!prev) return prev;
            return {
              ...prev,
              steps: prev.steps.map((s) => (s.id === data.step_id ? { ...s, status: 'running' } : s))
            };
          });
          setLogs((prev) => [...prev, `[${timestamp}] ⚙️ Executing [${data.step_id}]: ${data.name} (tool: ${data.tool})`]);
        } else if (data.type === 'step_result') {
          setCurrentPlan((prev) => {
            if (!prev) return prev;
            return {
              ...prev,
              steps: prev.steps.map((s) => (s.id === data.step_id ? { ...s, status: 'completed', result: data.result, mock: data.mock } : s))
            };
          });
          const preview = String(data.result).slice(0, 180).replace(/\n/g, ' ');
          setLogs((prev) => [...prev, `[${timestamp}] ✅ Step [${data.step_id}] completed${data.mock ? ' [mock]' : ''}: ${preview}...`]);
        } else if (data.type === 'step_error') {
          setCurrentPlan((prev) => {
            if (!prev) return prev;
            return {
              ...prev,
              steps: prev.steps.map((s) => (s.id === data.step_id ? { ...s, status: 'failed', error: data.error } : s))
            };
          });
          setLogs((prev) => [...prev, `[${timestamp}] ❌ Step [${data.step_id}] failed: ${data.error}`]);
        } else if (data.type === 'workflow_complete') {
          setIsRunning(false);
          setActiveStepId(null);
          setLogs((prev) => [
            ...prev,
            `[${timestamp}] 🏁 Workflow finished with status: ${data.status.toUpperCase()} in ${data.duration_seconds}s`
          ]);
          es.close();
          fetchWorkflows();
        } else if (data.type === 'workflow_cancelled') {
          setIsRunning(false);
          setActiveStepId(null);
          setLogs((prev) => [...prev, `[${timestamp}] 🛑 Workflow was cancelled.`]);
          es.close();
          fetchWorkflows();
        } else if (data.type === 'error') {
          setErrorMsg(data.error);
          setIsRunning(false);
          setActiveStepId(null);
          es.close();
        }
      } catch (parseErr) {
        console.error('Error parsing SSE event:', parseErr);
      }
    };

    es.onerror = () => {
      setIsRunning(false);
      setActiveStepId(null);
      es.close();
    };
  };

  const handleCancelWorkflow = async () => {
    if (!currentPlan) return;
    try {
      await fetch(`/api/workflows/${currentPlan.workflow_id}/cancel`, { method: 'POST' });
      setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] Requesting cancellation...`]);
    } catch (e) {
      console.warn('Failed to cancel workflow:', e);
    }
  };

  const handleLoadSavedWorkflow = async (wf) => {
    try {
      const res = await fetch(`/api/workflows/${wf.id}`);
      if (res.ok) {
        const fullWf = await res.json();
        setCurrentPlan(fullWf.plan);
        setSelectedHistoryWorkflow(fullWf);
        setSelectedStep(fullWf.plan.steps && fullWf.plan.steps[0] ? fullWf.plan.steps[0] : null);
        setLogs([]);
      }
    } catch (e) {
      console.warn('Failed to load workflow details:', e);
    }
  };

  const handleDeleteWorkflow = async (e, wfId) => {
    e.stopPropagation();
    try {
      const res = await fetch(`/api/workflows/${wfId}`, { method: 'DELETE' });
      if (res.ok) {
        if (currentPlan && currentPlan.workflow_id === wfId) {
          setCurrentPlan(null);
        }
        fetchWorkflows();
      }
    } catch (err) {
      console.warn('Delete workflow failed:', err);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-cyan-950/40 via-slate-900/60 to-violet-950/40 border border-white/10 shadow-2xl backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
              <Layers className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-bold font-display text-white">
              Prompt-to-Workflow <span className="text-cyan-400">Engine</span>
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 max-w-2xl">
            Turn natural language tasks (in English, Hindi or Urdu) into autonomous, executable step graphs with zero hand-wiring.
          </p>
        </div>

        {/* Quick Stats Pill */}
        <div className="flex items-center gap-2 self-start md:self-auto px-3 py-1.5 rounded-2xl bg-white/5 border border-white/10 text-xs text-slate-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Strict Registered Tools Only</span>
        </div>
      </div>

      {/* Top Workflow Builder Section: Input + Conversational Questions Panel */}
      <div className={`grid grid-cols-1 ${questionsSession ? 'lg:grid-cols-12' : ''} gap-6 items-start`}>
        
        {/* Left / Main Column: Task Input & Starter Templates */}
        <div className={`${questionsSession ? 'lg:col-span-7' : 'w-full'} space-y-4`}>
          <div className="glass-panel rounded-2xl p-4 sm:p-5 border border-white/10 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>Describe your workflow task</span>
              </label>
              <span className="text-[11px] text-slate-400">English, हिन्दी or اردو</span>
            </div>

            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="E.g., 'Send me the weather report every day at 5 PM by email' or 'Roz subah 8 baje top AI news mere Gmail par bhejo'..."
              rows={3}
              disabled={isExtracting || isGenerating || isRunning}
              className="w-full bg-slate-950/50 text-slate-100 placeholder:text-slate-500 text-sm outline-none resize-none p-3 rounded-xl border border-white/10 focus:border-cyan-500/50 transition-colors"
            />

            {/* Action Controls & Voice Input */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div className="flex items-center gap-2">
                <VoiceInputButton 
                  onTranscript={(t) => setPrompt((prev) => (prev ? `${prev} ${t}` : t))} 
                  disabled={isExtracting || isGenerating || isRunning} 
                />

                {/* Dry Run Mode Switch */}
                <label className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-xs text-slate-300 cursor-pointer hover:bg-white/10 transition-colors">
                  <input
                    type="checkbox"
                    checked={dryRun}
                    onChange={(e) => setDryRun(e.target.checked)}
                    disabled={isRunning}
                    className="w-3.5 h-3.5 rounded accent-cyan-500 cursor-pointer"
                  />
                  <span className="font-medium">Dry Run (Simulate)</span>
                </label>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleExtractAndBuildWorkflow()}
                  disabled={!prompt.trim() || isExtracting || isGenerating || isRunning}
                  className="px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-lg shadow-cyan-500/25 transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isExtracting ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Analyzing Requirements...</span>
                    </>
                  ) : isGenerating ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Architecting Plan...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Build Workflow</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* 1-Click Templates */}
            <div className="pt-3 border-t border-white/5">
              <span className="text-[11px] font-medium text-slate-400 mb-2 block">Quick Examples (1-Click):</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {WORKFLOW_TEMPLATES.map((tmpl, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setPrompt(tmpl.prompt);
                      handleExtractAndBuildWorkflow(tmpl.prompt);
                    }}
                    disabled={isExtracting || isGenerating || isRunning}
                    className="text-left p-2.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 transition-all group"
                  >
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300 truncate">
                        {tmpl.title}
                      </span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                        {tmpl.badge}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 line-clamp-1">{tmpl.prompt}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Questions Panel */}
        {questionsSession && (
          <div className="lg:col-span-5">
            <QuestionsPanel
              session={questionsSession}
              onAnswer={handleAnswerQuestion}
              onReset={() => setQuestionsSession(null)}
              isSubmitting={isAnswering || isGenerating}
            />
          </div>
        )}

      </div>

      {/* Error Banner */}
      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-950/80 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-3 shadow-lg">
          <AlertTriangle className="w-5 h-5 text-rose-400 flex-shrink-0" />
          <span className="flex-1 font-medium">{errorMsg}</span>
          <button onClick={() => setErrorMsg('')} className="text-rose-400 hover:text-white">&times;</button>
        </div>
      )}

      {/* Missing Credentials Alert Banner */}
      {currentPlan && currentPlan.missing_credentials && currentPlan.missing_credentials.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-950/60 border border-amber-500/40 text-amber-200 text-xs space-y-2 shadow-lg backdrop-blur-md">
          <div className="flex items-center gap-2 font-semibold text-amber-300">
            <Key className="w-4 h-4 text-amber-400" />
            <span>Missing Integration Credentials Detected</span>
          </div>
          <p className="text-[11px] text-amber-200/80">
            This workflow uses tools that require configuration in your server <code className="bg-black/40 px-1 py-0.5 rounded font-mono">.env</code> file. Without them, actions will safely run in simulation mode.
          </p>
          <ul className="list-disc list-inside space-y-1 text-[11px] font-mono text-amber-300/90 pl-1">
            {currentPlan.missing_credentials.map((mc, i) => (
              <li key={i}>
                <strong>{mc.key}</strong>: {mc.instructions}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Visual Workflow Graph & Execution Panel */}
      {currentPlan && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/60 border border-white/10">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>{currentPlan.title}</span>
                {dryRun && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-violet-500/20 text-violet-300 border border-violet-500/30">
                    Dry Run Mode
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-400">{currentPlan.description}</p>
            </div>

            {/* Run & Cancel Buttons */}
            <div className="flex items-center gap-2">
              {isRunning ? (
                <button
                  type="button"
                  onClick={handleCancelWorkflow}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/30 transition-all flex items-center gap-2"
                >
                  <Square className="w-3.5 h-3.5" />
                  <span>Cancel Run</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleRunWorkflow}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30 transition-all flex items-center gap-2"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{dryRun ? 'Simulate Dry Run' : 'Execute Workflow'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Step Graph Canvas */}
          <div className="glass-panel p-4 rounded-2xl border border-white/10">
            <WorkflowGraph
              steps={currentPlan.steps || []}
              activeStepId={activeStepId}
              selectedStepId={selectedStep ? selectedStep.id : null}
              onSelectStep={(s) => setSelectedStep(s)}
            />
          </div>

          {/* Step Inspector & Live Execution Terminal */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            
            {/* Step Node Inspector */}
            <div className="glass-panel p-4 rounded-2xl border border-white/10 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-white/10 mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Step Node Inspector</span>
                  </h3>
                  {selectedStep && (
                    <span className="font-mono text-[10px] text-cyan-400 bg-cyan-950/50 px-2 py-0.5 rounded border border-cyan-500/20">
                      {selectedStep.id}
                    </span>
                  )}
                </div>

                {selectedStep ? (
                  <div className="space-y-2.5 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[11px]">Step Title:</span>
                      <span className="font-semibold text-white">{selectedStep.name}</span>
                    </div>

                    <div>
                      <span className="text-slate-400 block text-[11px]">Tool Function:</span>
                      <code className="text-cyan-300 font-mono text-[11px] bg-slate-950 px-1.5 py-0.5 rounded border border-white/5">
                        {selectedStep.tool}
                      </code>
                    </div>

                    <div>
                      <span className="text-slate-400 block text-[11px]">Input Parameters:</span>
                      <pre className="bg-slate-950/80 p-2.5 rounded-xl border border-white/5 font-mono text-[11px] text-slate-300 overflow-x-auto max-h-36 custom-scrollbar">
                        {JSON.stringify(selectedStep.params, null, 2)}
                      </pre>
                    </div>

                    {selectedStep.output_key && (
                      <div>
                        <span className="text-slate-400 block text-[11px]">Output Context Key:</span>
                        <code className="text-violet-300 font-mono text-[11px] bg-slate-950 px-1.5 py-0.5 rounded">
                          &#123;&#123;{selectedStep.output_key}&#125;&#125;
                        </code>
                      </div>
                    )}

                    {selectedStep.result && (
                      <div>
                        <span className="text-slate-400 block text-[11px]">Execution Result:</span>
                        <pre className="bg-slate-950/90 p-2.5 rounded-xl border border-emerald-500/30 font-mono text-[11px] text-emerald-300 overflow-x-auto max-h-40 custom-scrollbar whitespace-pre-wrap">
                          {selectedStep.result}
                        </pre>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500">Click any step node in the graph above to inspect parameters and outputs.</p>
                )}
              </div>
            </div>

            {/* Live Terminal Logs */}
            <div className="glass-panel p-4 rounded-2xl border border-white/10 flex flex-col">
              <div className="flex items-center justify-between pb-2 border-b border-white/10 mb-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Execution Logs</span>
                </h3>
                {isRunning && (
                  <span className="flex items-center gap-1.5 text-[10px] text-cyan-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                    Streaming SSE
                  </span>
                )}
              </div>

              <div
                ref={logContainerRef}
                className="flex-1 bg-slate-950/90 rounded-xl p-3 font-mono text-[11px] leading-relaxed text-slate-300 border border-white/5 overflow-y-auto max-h-64 min-h-[160px] space-y-1.5 custom-scrollbar"
              >
                {logs.length === 0 ? (
                  <span className="text-slate-600 italic">No execution events yet. Click 'Execute Workflow' or 'Simulate Dry Run' to begin.</span>
                ) : (
                  logs.map((line, idx) => (
                    <div key={idx} className="whitespace-pre-wrap break-words">
                      {line}
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Saved Workflows History (Survives Restarts) */}
      <div className="glass-panel p-5 rounded-2xl border border-white/10 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <History className="w-4 h-4 text-cyan-400" />
            <span>Saved Workflows & Re-run History</span>
          </h3>
          <span className="text-xs text-slate-400">{workflowsHistory.length} Saved in SQLite</span>
        </div>

        {workflowsHistory.length === 0 ? (
          <p className="text-xs text-slate-500 italic">No saved workflows yet. Every workflow you generate is automatically saved here for scheduled re-runs.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {workflowsHistory.map((wf) => (
              <div
                key={wf.id}
                onClick={() => handleLoadSavedWorkflow(wf)}
                className="p-3.5 rounded-xl bg-white/[0.02] hover:bg-white/[0.06] border border-white/10 transition-all cursor-pointer flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300 truncate" title={wf.title}>
                      {wf.title}
                    </span>
                    <span className={`text-[9px] px-1.5 py-0.2 rounded uppercase font-medium ${
                      wf.status === 'completed' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                      wf.status === 'running' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' :
                      'bg-slate-800 text-slate-400 border border-white/5'
                    }`}>
                      {wf.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-2 mb-2">{wf.prompt}</p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[10px] text-slate-500">
                  <span>{new Date(wf.created_at).toLocaleDateString()}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-cyan-400 group-hover:underline flex items-center gap-0.5">
                      Open <ArrowRight className="w-2.5 h-2.5" />
                    </span>
                    <button
                      type="button"
                      onClick={(e) => handleDeleteWorkflow(e, wf.id)}
                      className="text-slate-500 hover:text-rose-400 p-1"
                      title="Delete workflow"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
