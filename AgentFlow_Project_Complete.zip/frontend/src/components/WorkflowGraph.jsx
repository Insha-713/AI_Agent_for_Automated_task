import React from 'react';
import { 
  Clock, 
  Newspaper, 
  Search, 
  Globe, 
  Compass, 
  FileText, 
  Folder, 
  Mail, 
  CheckCircle2, 
  AlertCircle, 
  Clock3, 
  ShieldAlert, 
  ArrowRight,
  ArrowDown,
  Sparkles,
  Layers
} from 'lucide-react';

const TOOL_ICONS = {
  get_datetime: Clock,
  get_latest_news: Newspaper,
  multi_search: Search,
  web_search: Search,
  fetch_page: Globe,
  search_sources: Compass,
  save_file: FileText,
  read_file: Folder,
  list_files: Folder,
  send_email: Mail,
};

export default function WorkflowGraph({ 
  steps = [], 
  activeStepId = null, 
  selectedStepId = null,
  onSelectStep = () => {} 
}) {
  if (!steps || steps.length === 0) {
    return (
      <div className="p-8 text-center border border-dashed border-white/10 rounded-2xl bg-white/[0.02]">
        <Layers className="w-10 h-10 text-slate-500 mx-auto mb-3 opacity-60" />
        <p className="text-sm text-slate-400 font-medium">No workflow plan generated yet</p>
        <p className="text-xs text-slate-500 mt-1">
          Type or speak a task above to automatically generate a visual step graph.
        </p>
      </div>
    );
  }

  return (
    <div className="w-full overflow-x-auto py-4 px-2 custom-scrollbar">
      <div className="flex flex-col lg:flex-row items-center justify-start gap-4 min-w-max">
        {steps.map((step, index) => {
          const Icon = TOOL_ICONS[step.tool] || Sparkles;
          const isLast = index === steps.length - 1;
          const isRunning = activeStepId === step.id || step.status === 'running';
          const isCompleted = step.status === 'completed';
          const isFailed = step.status === 'failed';
          const isSelected = selectedStepId === step.id;

          // Border & Glow styling based on execution status
          let borderClass = 'border-white/10 bg-slate-900/60';
          let glowClass = '';

          if (isRunning) {
            borderClass = 'border-cyan-400 bg-cyan-950/40 ring-2 ring-cyan-400/50 shadow-glow-cyan';
            glowClass = 'animate-pulse';
          } else if (isCompleted) {
            borderClass = 'border-emerald-500/40 bg-emerald-950/20';
          } else if (isFailed) {
            borderClass = 'border-rose-500/50 bg-rose-950/30';
          } else if (step.requires_approval) {
            borderClass = 'border-amber-500/30 bg-amber-950/20';
          }

          if (isSelected) {
            borderClass += ' ring-2 ring-violet-400 shadow-glow-violet';
          }

          return (
            <React.Fragment key={step.id || index}>
              {/* Step Card Node */}
              <div
                onClick={() => onSelectStep(step)}
                className={`relative w-72 p-4 rounded-2xl border backdrop-blur-md cursor-pointer transition-all duration-200 hover:scale-[1.02] ${borderClass} ${glowClass}`}
              >
                {/* Node Top Header */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <div className={`p-2 rounded-xl ${
                      isCompleted ? 'bg-emerald-500/20 text-emerald-400' :
                      isRunning ? 'bg-cyan-500/20 text-cyan-400' :
                      isFailed ? 'bg-rose-500/20 text-rose-400' :
                      'bg-white/5 text-slate-300'
                    }`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-slate-400 tracking-wider uppercase">
                        Step {index + 1}
                      </span>
                      <h4 className="text-xs font-semibold text-white truncate max-w-[150px]" title={step.name}>
                        {step.name}
                      </h4>
                    </div>
                  </div>

                  {/* Status Indicator Badge */}
                  {isRunning ? (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping"></span>
                      Running
                    </span>
                  ) : isCompleted ? (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      <CheckCircle2 className="w-3 h-3" />
                      Done
                    </span>
                  ) : isFailed ? (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-rose-500/20 text-rose-300 border border-rose-500/30">
                      <AlertCircle className="w-3 h-3" />
                      Failed
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-800 text-slate-400 border border-white/5">
                      <Clock3 className="w-3 h-3" />
                      Pending
                    </span>
                  )}
                </div>

                {/* Tool Description */}
                <p className="text-[11px] text-slate-400 line-clamp-2 mb-3 min-h-[32px]">
                  {step.description || `Executes registered tool: ${step.tool}`}
                </p>

                {/* Step Metadata Footer */}
                <div className="pt-2 border-t border-white/5 flex flex-wrap items-center justify-between gap-1.5 text-[10px]">
                  <span className="font-mono text-cyan-400/90 bg-cyan-950/40 px-1.5 py-0.5 rounded border border-cyan-500/20">
                    {step.tool}
                  </span>

                  {step.output_key && (
                    <span className="font-mono text-slate-400 bg-white/5 px-1.5 py-0.5 rounded truncate max-w-[110px]" title={`Output variable: {{${step.output_key}}}`}>
                      &rarr; &#123;&#123;{step.output_key}&#125;&#125;
                    </span>
                  )}
                </div>

                {/* Approval or Mock Banner */}
                {step.requires_approval && (
                  <div className="mt-2 pt-1.5 border-t border-amber-500/20 flex items-center gap-1 text-[10px] text-amber-300">
                    <ShieldAlert className="w-3 h-3 text-amber-400 flex-shrink-0" />
                    <span>Requires Human Approval</span>
                  </div>
                )}
                {step.mock && (
                  <div className="mt-1 text-[9px] font-mono text-violet-300 bg-violet-950/40 px-1.5 py-0.5 rounded border border-violet-500/30 inline-block">
                    [mock] Simulated Output
                  </div>
                )}
              </div>

              {/* Connecting Connector Arrow between nodes */}
              {!isLast && (
                <div className="flex items-center justify-center text-slate-500 py-1 lg:py-0">
                  <div className="hidden lg:flex items-center gap-1">
                    <span className="w-4 h-[2px] bg-gradient-to-r from-cyan-500/50 to-violet-500/50"></span>
                    <ArrowRight className="w-4 h-4 text-cyan-400 animate-pulse" />
                  </div>
                  <div className="flex lg:hidden items-center justify-center">
                    <ArrowDown className="w-4 h-4 text-cyan-400 animate-bounce" />
                  </div>
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}
