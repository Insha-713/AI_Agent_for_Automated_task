import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShieldAlert, Check, X, Mail, FileWarning, AlertTriangle, ArrowRight } from 'lucide-react';

export default function ApprovalCard({ approval, onResolve }) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [resolvedDecision, setResolvedDecision] = useState(null);

  if (!approval) return null;

  const handleDecision = async (decision) => {
    if (isSubmitting) return;
    setIsSubmitting(true);

    try {
      const resp = await fetch(`/api/approvals/${approval.approval_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ decision })
      });

      if (resp.ok) {
        setResolvedDecision(decision);
        if (onResolve) {
          onResolve(approval.approval_id, decision);
        }
      }
    } catch (err) {
      console.error('Failed to resolve approval:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const isEmail = approval.action_type === 'send_email';
  const isOverwrite = approval.action_type === 'overwrite_file';

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95, y: -10 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="p-5 rounded-2xl border border-amber-500/50 bg-gradient-to-br from-amber-950/40 via-slate-900/90 to-slate-950 shadow-2xl relative overflow-hidden"
    >
      {/* Glowing top line */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-rose-500 to-amber-500 animate-pulse" />

      {/* Header */}
      <div className="flex items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            {isEmail ? <Mail className="w-5 h-5" /> : isOverwrite ? <FileWarning className="w-5 h-5" /> : <ShieldAlert className="w-5 h-5" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white font-display uppercase tracking-wide">
                Human-In-The-Loop Approval Required
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/40 animate-pulse">
                ACTION PAUSED
              </span>
            </div>
            <p className="text-xs text-slate-400">
              AgentFlow needs your explicit authorization before proceeding with this sensitive action.
            </p>
          </div>
        </div>
      </div>

      {/* Action Details Card */}
      <div className="my-3 p-3.5 rounded-xl bg-black/40 border border-white/10 text-xs space-y-2">
        <div className="flex items-center justify-between text-slate-300">
          <span className="font-semibold text-amber-300">Action:</span>
          <span className="font-mono text-cyan-300">{approval.tool} ({approval.action_type})</span>
        </div>

        <p className="text-slate-200 leading-relaxed font-medium">
          {approval.details}
        </p>

        {/* Specific Email Details */}
        {isEmail && approval.args && (
          <div className="mt-2 pt-2 border-t border-white/5 space-y-1 font-mono text-[11px]">
            <div className="text-slate-400"><strong className="text-slate-200">Recipient:</strong> {approval.args.to_email}</div>
            <div className="text-slate-400"><strong className="text-slate-200">Subject:</strong> {approval.args.subject}</div>
            {approval.args.body_preview && (
              <div className="mt-1 p-2 rounded bg-slate-900 text-slate-300 whitespace-pre-wrap max-h-24 overflow-y-auto">
                {approval.args.body_preview}
              </div>
            )}
          </div>
        )}

        {/* Specific File Overwrite Details */}
        {isOverwrite && approval.args && (
          <div className="mt-2 pt-2 border-t border-white/5 space-y-1 font-mono text-[11px]">
            <div className="text-slate-400"><strong className="text-slate-200">Target File:</strong> {approval.args.filename}</div>
            <div className="text-slate-400"><strong className="text-slate-200">Existing Size:</strong> {approval.args.existing_size} bytes</div>
            <div className="text-slate-400"><strong className="text-slate-200">New Content Size:</strong> {approval.args.new_size} bytes</div>
          </div>
        )}
      </div>

      {/* Decision Buttons */}
      {resolvedDecision ? (
        <div className="pt-2 flex items-center justify-center gap-2 text-xs font-semibold">
          {resolvedDecision === 'approve' ? (
            <span className="text-emerald-400 flex items-center gap-1.5">
              <Check className="w-4 h-4" /> Action Approved. Agent resuming...
            </span>
          ) : (
            <span className="text-rose-400 flex items-center gap-1.5">
              <X className="w-4 h-4" /> Action Rejected. Agent skipping...
            </span>
          )}
        </div>
      ) : (
        <div className="pt-2 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={() => handleDecision('reject')}
            disabled={isSubmitting}
            className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
            <span>Reject / Cancel</span>
          </button>

          <button
            type="button"
            onClick={() => handleDecision('approve')}
            disabled={isSubmitting}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-white font-semibold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 transition-all"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Approve & Continue</span>
          </button>
        </div>
      )}

    </motion.div>
  );
}
